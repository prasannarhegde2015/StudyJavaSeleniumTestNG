package ObjectLibrary;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import CommonFunctions.Helper;
import CommonFunctions.SeleniumActions;

public class IncidentPage extends SeleniumActions {
	
	public WebDriverWait wait ;
	Helper hlp = new Helper();
	private String _inctimestampt;
	
	public String getInctimestampt() { return this._inctimestampt ;}
	public void setInctimestampt(String Inctimestampt ) { this._inctimestampt = Inctimestampt;}
	
	
	public void createnewincident(WebDriver drv)
	{
		hlp.setName("IncidentPage.Properties");
		wait = new WebDriverWait(drv, 500);
		drv.switchTo().frame(drv.findElement(By.cssSelector(hlp.readpropertiesfileall().getProperty("cssselectorNavigationFrame"))));
		//*****click New button
		 System.out.println("Time before button found"+ new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss")
					.format(new Date()));
		WebElement btnNew = null;
		try
		{
			wait.until(ExpectedConditions.presenceOfElementLocated(By.id(hlp.readpropertiesfileall().getProperty("idbtnNew"))));
			btnNew = drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idbtnNew")));
			System.out.println("Time after button found"+ new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss")
					.format(new Date()));
		}
		catch(NoSuchElementException e)
		{
			System.out.println("Elenent not found");
		}
		catch(StaleElementReferenceException e)
		{
			System.out.println("StaleElement ref errro");
		}
		catch(Exception e)
		{
			System.out.println("Other Error");
		}
		if (btnNew != null )
		{
			System.out.println("New button was found");
			movetoelem(drv, btnNew );
			clickelem(drv, btnNew );
	//	drv.findElement(By.id("sysverb_new")).click();
		}
		else
		{
			System.out.println("Elenent not found: Test Aborted");
			return;
		}
	}

	public void enterIncidentNumber(WebDriver drv, String incnum) throws InterruptedException
	{
		hlp.setName("IncidentPage.Properties");
		String now = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss")
				.format(new Date());
				String strnow = now.toString();
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(hlp.readpropertiesfileall().getProperty("idtxtfldIncidentNumber"))));
		Thread.sleep(2000);
		drv.findElement(By.id("incident.number")).clear();
		drv.findElement(By.id("incident.number")).sendKeys(incnum+strnow);
		setInctimestampt(strnow);
	}
    

	public void enterimpact(WebDriver drv , String incval)
    {
    	Select sl = new Select(drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idselectIncImpact") )));
		sl.selectByVisibleText(incval);
		
    }

    public void entershortdesc(WebDriver drv , String shortdesc)
   {
	   drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idtxtareaIncshortdesc"))).sendKeys(shortdesc);
   }
    
    public void enterlongdesc(WebDriver drv , String longdesc)
    {
    	drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idtxtareaFullDec"))).sendKeys(longdesc);
    }
    
    public void submitIncident(WebDriver drv)
    {
    	drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idbtnIncSubmit"))).click();
    }
   
    public void ClickNewlycreatedLink(WebDriver drv, String shortdesc) throws InterruptedException
    {
    	wait.until(ExpectedConditions.presenceOfElementLocated(By.linkText(shortdesc+getInctimestampt())));
		wait.until(ExpectedConditions.elementToBeClickable(By.linkText(shortdesc+getInctimestampt())));
		if (isstale(drv, drv.findElement(By.linkText(shortdesc+getInctimestampt()))) )
		{
		   wait(5);
		   drv.findElement(By.linkText(shortdesc+getInctimestampt())).click();
		}
    }
    
    public void VerifyImactvalueonNewis(WebDriver drv , String vincval)
    {
    	Select sl2 = new Select(drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idselectIncState") )));
		System.out.println("The State dropdown value is: "+sl2.getFirstSelectedOption().getText());
		//Verify.verify(sl2.getFirstSelectedOption().getText().equals("New"), "TC_State_Name_Fail", "TC1_FAIL");
	//	org.junit.Assert.assertFalse(message, condition);
		if (sl2.getFirstSelectedOption().getText().equals("New"))
		{
			System.out.println("Status:PASS --- The Incidnet State Value Expected = New , Actual "+sl2.getFirstSelectedOption().getText());
		}
		else
		{
			System.out.println("Status:FAIL --- The Incidnet State Value Expected = New , Actual "+sl2.getFirstSelectedOption().getText());
		}
		
    }
}
