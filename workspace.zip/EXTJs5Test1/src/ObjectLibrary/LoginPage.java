package ObjectLibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import CommonFunctions.Helper;

public class LoginPage {
	
	public void login(WebDriver drv,String username, String passowrd)
	{
		WebDriverWait wait ;
		try
		{
			
			Helper hlp = new Helper();
			hlp.setName("LoginPage.Properties");
			wait = new WebDriverWait(drv, 500);
	//	));
		drv.switchTo().frame(0);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id(hlp.readpropertiesfileall().get("idusername").toString())));
		drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idusername"))).clear();
		drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idusername"))).sendKeys(username);
		drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idpassword"))).clear();
		drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idpassword"))).sendKeys(passowrd);
		//drv.findElement(By.id("user_password")).sendKeys("kWu5cLfuTare");
		
		drv.findElement(By.id(hlp.readpropertiesfileall().getProperty("idlogin"))).click();
		}
		catch( NoSuchElementException e)
		{
			System.out.println(" No such element");
		}
		catch ( StaleElementReferenceException e)
		{
			System.out.println(" Element not attached to page");
		}
		catch(Exception e)
		{
			System.out.println(" Other Exception "+e);
		}
	}
}
