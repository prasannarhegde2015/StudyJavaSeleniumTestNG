package ObjectLibrary;

public class Objectdef {

}
