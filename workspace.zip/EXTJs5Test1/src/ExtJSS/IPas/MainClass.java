package ExtJSS.IPas;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import ObjectLibrary.HomePage;
import ObjectLibrary.IncidentPage;
import ObjectLibrary.LoginPage;

public class MainClass {
	
	public static String baseurl = "https://dev23478.service-now.com";
	public static String iedriverpath = "D:\\Prasanna\\Automation\\Selenium\\Selenium Jar and Drivers\\IEDriverServer_Win32_2.53.1\\IEDriverServer.exe";
	public static String CHROMEdriverpath = "D:\\Prasanna\\Automation\\Selenium\\Selenium Jar and Drivers\\chromedriver_win32\\chromedriver.exe";
    public static WebDriver globalDriver = null;
	
	public static void main(String[] args) throws InterruptedException
	{
		//************************************ Page Objects *************************************
		 LoginPage pgLogin = new LoginPage();
		 HomePage pgHome = new HomePage();
		 IncidentPage pgInc = new IncidentPage();
		 
		System.out.println("************* Test has Started ************* : "+ new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss")
					.format(new Date()));
		setupdriver();
		pgLogin.login(globalDriver,"admin","ServiceNow97bd916$");		
	
		pgHome.ClickHomePanelLink(globalDriver, "Incidents");
		
		pgInc.createnewincident(globalDriver);
		pgInc.enterIncidentNumber(globalDriver, "IMC");
		
		pgInc.entershortdesc(globalDriver, "Incident number..");
		pgInc.enterimpact(globalDriver, "2 - Medium");
		pgInc.enterlongdesc(globalDriver, "Incident number..Detailed Comments ...");
		pgInc.submitIncident(globalDriver);
		pgInc.ClickNewlycreatedLink(globalDriver,"IMC");
		pgInc.VerifyImactvalueonNewis(globalDriver, "2 - Medium");
		
		pgHome.performLogout(globalDriver);
		System.out.println("************* Test has Ended *************: "+ new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss")
					.format(new Date()));
		
	}
	
	public static void  setupdriver()
	{
		
		System.setProperty("webdriver.chrome.driver", CHROMEdriverpath);
		ChromeOptions options = new ChromeOptions();
		options.addArguments("chrome.switches","--disable-extensions");
		globalDriver= new ChromeDriver(options);
		/*System.setProperty("webdriver.ie.driver", iedriverpath);
		drv = new InternetExplorerDriver();*/
		globalDriver.manage().window().maximize();
		globalDriver.get(baseurl);
		
	}

}
